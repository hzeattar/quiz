<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-visual-editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}

?>

<div class="info-text orange tve-post-list-link-info tcb-hidden">
	<?php echo esc_html__( 'This option is disabled because you have set the content link for the entire item.', 'thrive-cb' ); ?>
</div>
