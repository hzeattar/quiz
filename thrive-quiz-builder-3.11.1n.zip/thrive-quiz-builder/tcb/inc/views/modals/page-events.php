<span class="tcb-modal-title m-0 mb-20"><?php echo esc_html__( 'Page Event Manager', 'thrive-cb' ) ?></span>
<div class="modal-header"></div>
<div class="page-events">
	<div id="events-form"></div>
</div>
