<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-visual-editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>
</div>
<?php do_action( 'get_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html>

