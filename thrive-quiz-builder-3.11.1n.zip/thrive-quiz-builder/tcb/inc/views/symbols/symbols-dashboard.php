<div class="symbols-dashboard-container">
	<?php echo esc_html__( 'Symbols', 'thrive-cb' ) ?>
</div>
