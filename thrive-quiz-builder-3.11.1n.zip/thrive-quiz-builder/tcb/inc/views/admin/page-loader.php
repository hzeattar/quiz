<style type="text/css">
    #tcb-admin-page-loader {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1000;
        background: rgba(0, 0, 0, .4);
        display: none;
    }

    #tcb-admin-page-loader img {
        position: absolute;
        top: 50%;
        left: 50%;
        margin: -25px 0 0 -25px;
    }
</style>
<div id="tcb-admin-page-loader">
	<img src="<?php echo esc_url( tve_editor_css( 'images/loader_transparent.gif' ) ); ?>" alt="" width="50" height="50"/>
</div>
