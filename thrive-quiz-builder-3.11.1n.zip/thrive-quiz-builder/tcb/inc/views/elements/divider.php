<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 4/20/2017
 * Time: 4:00 PM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv-divider" data-style-d="tve_sep-1" data-thickness-d="3" data-color-d="rgb(66, 66, 66)">
	<hr class="tve_sep tve_sep-1">
</div>
