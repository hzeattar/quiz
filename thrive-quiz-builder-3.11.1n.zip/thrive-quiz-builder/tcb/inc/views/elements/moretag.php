<p class="tve_more_tag"><span class="tve_no_edit"><?php echo esc_html__( 'More...', 'thrive-cb' ) ?></span></p>
