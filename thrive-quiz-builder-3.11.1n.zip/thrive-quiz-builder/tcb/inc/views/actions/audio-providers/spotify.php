<div class="control-grid full-width">
	<label for="a-spotify-url">URL</label>
	<input type="text" data-setting="url" class="change audio-url tve_provider_url" data-fn="changeInput" id="a-spotify-url" placeholder="e.g. https://open.spotify.com/album/60GMfKsppuyvSG36HurCMz">
</div>
<div class="url-validate inline-message"></div>
